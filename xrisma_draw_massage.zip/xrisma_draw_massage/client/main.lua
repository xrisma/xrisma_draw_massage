ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

RegisterCommand('drawtext', function()
    ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'drawtext_message', {
        title = 'Enter your message'
    }, function(data, menu)
        local message = data.value

        if message and message ~= "" then
            menu.close()

            ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'drawtext_duration', {
                title = 'Enter duration in minutes'
            }, function(data2, menu2)
                local duration = tonumber(data2.value)

                if duration then
                    local playerPed = PlayerPedId()
                    local coords = GetEntityCoords(playerPed)

                    -- Update the server for the text display
                    TriggerServerEvent('xrisma_draw_massage:showText', message, coords, duration * 60) -- convert to seconds
                    menu2.close()
                else
                    ESX.ShowNotification('Invalid duration')
                end
            end, function(data2, menu2)
                menu2.close()
            end)
        else
            ESX.ShowNotification('Invalid message')
        end
    end, function(data, menu)
        menu.close()
    end)
end)

RegisterNetEvent('xrisma_draw_massage:displayText')
AddEventHandler('xrisma_draw_massage:displayText', function(message, coords, duration)
    local startTime = GetGameTimer()

    Citizen.CreateThread(function()
        while GetGameTimer() - startTime < duration * 1000 do
            Citizen.Wait(0)
            local playerCoords = GetEntityCoords(PlayerPedId())
            local distance = Vdist(playerCoords, coords)

            if distance < 5.0 then
                Draw3DText(message, coords)
            end
        end
    end)
end)

function Draw3DText(text, coords)
    local emoji = "💬 "
    local fullText = emoji .. text -- Add the emoji at the beginning of the message

    SetTextScale(0.50, 0.50) --Increase font size
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(fullText)
    SetDrawOrigin(coords.x, coords.y, coords.z + 1.0, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end
