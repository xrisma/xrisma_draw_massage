fx_version 'cerulean'
games { 'gta5' }

author 'Xrisma scripts'
description 'xrisma_draw_massage - A simple text drawing script'
version '1.0.0'

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

dependencies {
    'es_extended',
    'esx_menu_default'
}
