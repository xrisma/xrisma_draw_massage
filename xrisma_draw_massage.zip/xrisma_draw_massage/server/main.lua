ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('xrisma_draw_massage:showText')
AddEventHandler('xrisma_draw_massage:showText', function(message, coords, duration)
    TriggerClientEvent('xrisma_draw_massage:displayText', -1, message, coords, duration)
end)
